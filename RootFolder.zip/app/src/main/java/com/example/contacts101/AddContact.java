package com.example.contacts101;

import android.content.Context;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainer;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class AddContact extends Fragment {


    TextInputEditText editFirstName;
    TextInputEditText editLastName;
    TextInputEditText editPhoneNum;
    Button addContactToListBtn;
    Contact contact;
    FirebaseDatabase database;
    DatabaseReference myRef;
    RadioGroup radioGroup;
    RadioButton radioButton;
    String gender;
    RadioButton maleRadioButton, femaleRadioButton;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_add_contact, container, false);
        editFirstName = v.findViewById(R.id.et_editFirstName);
        editLastName = v.findViewById(R.id.et_editLastNane);
        editPhoneNum = v.findViewById(R.id.et_editTextPhone);
        addContactToListBtn = v.findViewById(R.id.et_addContactToList);
        radioGroup = v.findViewById(R.id.radioGroup);
        maleRadioButton =  v.findViewById(R.id.et_male);
        femaleRadioButton = v.findViewById(R.id.et_female);
        myRef = FirebaseDatabase.getInstance().getReference("Contacts");




        addContactToListBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String firstName = editFirstName.getText().toString();
                String lastName = editLastName.getText().toString();
                String phoneNum = editPhoneNum.getText().toString();
                if (TextUtils.isEmpty(firstName)) {
                  editFirstName.setError("Fill in FirstName");
                    editFirstName.requestFocus();
                }
                else if (TextUtils.isEmpty(lastName)) {
                    editLastName.setError("Fill in LastName");
                    editLastName.requestFocus();
                }
                else if (TextUtils.isEmpty(phoneNum)) {
                    editPhoneNum.setError("We need a PhoneNumber");
                    editPhoneNum.requestFocus();
                }

            else {

                    check(v);
                    if (radioButton == maleRadioButton) {
                        Contact contact = new Contact(editFirstName.getText().toString(), editLastName.getText().toString(), editPhoneNum.getText().toString(), "Male");
                        if(contact.editPhoneNum.length()<10){
                            Toast.makeText(getActivity(), "Need a longer phone number", Toast.LENGTH_LONG).show();
                        }
                        if(contact.editPhoneNum.length()>10){
                            Toast.makeText(getActivity(), "Need a shorter phone number", Toast.LENGTH_LONG).show();
                        }
                        if(contact.editPhoneNum.length()==10) {
                            myRef.push().setValue(contact);
                            Toast.makeText(getActivity(), "You have successfully added a new contact!", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Contact contact = new Contact(editFirstName.getText().toString(), editLastName.getText().toString(), editPhoneNum.getText().toString(), "Female");
                        if(contact.editPhoneNum.length()<10){
                            Toast.makeText(getActivity(), "Need a longer phone number", Toast.LENGTH_LONG).show();
                        }
                        if(contact.editPhoneNum.length()>10) {
                            Toast.makeText(getActivity(), "Need a shorter phone number", Toast.LENGTH_LONG).show();
                        }
                        if(contact.editPhoneNum.length()==10) {
                            myRef.push().setValue(contact);
                            Toast.makeText(getActivity(), "You have successfully added a new contact!", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            }

        });

        // Inflate the layout for this fragment
        return v;
    }
    public void check(View v) {
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = v.findViewById(radioId);
    }



}
