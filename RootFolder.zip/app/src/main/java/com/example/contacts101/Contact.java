package com.example.contacts101;

import android.widget.Button;

public class Contact {
    String editFirstName;
    String editLastName;
    String editPhoneNum;
    String gender;

    public Contact(String editFirstName, String editLastName, String editPhoneNum, String gender) {
        this.editFirstName = editFirstName;
        this.editLastName = editLastName;
        this.editPhoneNum = editPhoneNum;
        this.gender = gender;
    }

    public String getEditFirstName() {
        return editFirstName;
    }

    public void setEditFirstName(String editFirstName) {
        this.editFirstName = editFirstName;
    }

    public String getEditLastName() {
        return editLastName;
    }

    public void setEditLastName(String editLastName) {
        this.editLastName = editLastName;
    }

    public String getEditPhoneNum() {
        return editPhoneNum;
    }

    public void setEditPhoneNum(String editPhoneNum) {
        this.editPhoneNum = editPhoneNum;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
}

