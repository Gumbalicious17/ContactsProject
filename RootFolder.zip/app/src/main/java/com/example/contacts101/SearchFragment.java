package com.example.contacts101;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainer;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class SearchFragment extends Fragment {


    RecyclerView recyclerView;
    FirebaseDatabase database;
    ArrayList<Contact> contacts = new ArrayList<>();
    AdapterClass adapter;
    Contact contact;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View v = inflater.inflate(R.layout.fragment_search, container, false);
        recyclerView= v.findViewById(R.id.et_recycle);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getActivity()));
        contacts = new ArrayList<>();


        adapter = new AdapterClass(this.getActivity(),contacts);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), RecyclerView.VERTICAL, false));




        DatabaseReference contact_ref = FirebaseDatabase.getInstance().getReference("Contacts");

        contact_ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String input="";
                Bundle extra=getArguments();
                if (snapshot.exists()) {
                    for(DataSnapshot dataSnapshot:snapshot.getChildren()) {

                        if(extra!=null){
                            input = extra.getString("input");
                        }

                            contact = new Contact(dataSnapshot.child("editFirstName").getValue().toString(),
                                    dataSnapshot.child("editLastName").getValue().toString(),
                                    dataSnapshot.child("editPhoneNum").getValue().toString(),
                                    dataSnapshot.child("gender").getValue().toString());

                        if(extra!=null) {

                            if (contact.getEditFirstName().contains(input)||contact.getEditLastName().contains(input)||contact.getEditPhoneNum().contains(input)) {
                                contacts.add(contact);
                            }
                        }
                        else {
                            contacts.add(contact);

                        }
                        adapter.notifyDataSetChanged();



                        }
                    }

                }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
        // Inflate the layout for this fragment
        return v;
    }



}
