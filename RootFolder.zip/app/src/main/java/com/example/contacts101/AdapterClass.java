package com.example.contacts101;

import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterClass extends RecyclerView.Adapter<AdapterClass.ViewHolder> {
    ArrayList<Contact> data = new ArrayList<>();

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_item, null));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.firstName.setText(data.get(position).editFirstName.toString());
        holder.lastName.setText(data.get(position).editLastName.toString());
        holder.phoneNumber.setText(data.get(position).editPhoneNum.toString());

    }

    @Override
    public int getItemCount() {
        return data.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView firstName, lastName,phoneNumber;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            firstName = itemView.findViewById(R.id.item_firstName);
            lastName = itemView.findViewById(R.id.item_lastName);
            phoneNumber= itemView.findViewById(R.id.item_phoneNumber);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String number="tel:"+phoneNumber.getText().toString();
                    Intent call = new Intent(Intent.ACTION_CALL);
                    call.setData(Uri.parse(number));
                    v.getContext().startActivity(call);
                }
            });

        }
    }
    public AdapterClass(FragmentActivity activity, ArrayList<Contact> data) {
        this.data = data;
    }

}