package com.example.contacts101;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    Button addContactBtn;
    Button searchContact;
    EditText searchInput;
    FragmentContainerView fragmentContainerView;
    FragmentManager fragmentManager;
    FragmentTransaction ft;
    Fragment fragment ;
    Fragment fragment1 ;
    Fragment fragment2 ;
    FirebaseDatabase database;
    DatabaseReference myRef;
    RecyclerView mRecyclerView;
    ArrayList<Contact> data= new ArrayList<>();
    Contact contact;
    Button callBtn;
    Button textBtn;
    String text="";
    String phoneNumber;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        callBtn=findViewById(R.id.et_call);
        textBtn=findViewById(R.id.et_text);
        mRecyclerView = findViewById(R.id.et_recycle);
        searchContact=findViewById(R.id.et_searchcontacts);
        searchInput=findViewById(R.id.et_searchNumber);
        addContactBtn = findViewById(R.id.et_addcontact);
        fragmentContainerView = findViewById(R.id.et_FragmentContainerView);
        fragment = new AddContact();
        fragmentManager = getSupportFragmentManager();
        ft = fragmentManager.beginTransaction();
        fragment1 = fragmentManager.findFragmentById(R.id.et_FragmentContainerView);
        ft.hide(fragment1);
        ft.commit();

        myRef = FirebaseDatabase.getInstance().getReference("Contacts");

        ActivityCompat.requestPermissions(MainActivity.this, new String[]{
                        Manifest.permission.CALL_PHONE,
                        Manifest.permission.SEND_SMS,
                        Manifest.permission.READ_SMS},
                PackageManager.PERMISSION_GRANTED);


        addContactBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment blank = new BlankFragment();
                getSupportFragmentManager().beginTransaction().replace(R.id.et_FragmentContainerView, fragment).commit();
                getSupportFragmentManager().beginTransaction().replace(R.id.et_searchContainer,blank).commit();

            }
        });

        searchContact.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("input",searchInput.getText().toString());
                fragment2= new SearchFragment();
                Fragment blank = new BlankFragment();
                fragment2.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.et_searchContainer, fragment2, null).setReorderingAllowed(true).addToBackStack(null).commit();
                getSupportFragmentManager().beginTransaction().replace(R.id.et_FragmentContainerView,blank).commit();
            }

        }));
        callBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number="tel:"+searchInput.getText().toString();
                Intent call = new Intent(Intent.ACTION_CALL);
                call.setData(Uri.parse(number));
                v.getContext().startActivity(call);
            }
        });
        textBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                myRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            phoneNumber = dataSnapshot.child("editPhoneNum").getValue(String.class);
                            String name = dataSnapshot.child("editFirstName").getValue(String.class);
                            String gender = dataSnapshot.child("gender").getValue(String.class);

                            if (phoneNumber.equals(searchInput.getText().toString())) {
                                if (gender.equals("Male"))
                                    text = "Hey dudeMannnn " + name + " call me back brotha!";
                                else
                                    text = "Hey girl " + name + " call me back honeypie darling woman! ";
                                sms();
                                break;
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
            }
        });

    }
    private void sms() {

        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(searchInput.getText().toString(), null, text, null, null);
        Toast.makeText(MainActivity.this, "Message sent!", Toast.LENGTH_LONG).show();

    }

}

